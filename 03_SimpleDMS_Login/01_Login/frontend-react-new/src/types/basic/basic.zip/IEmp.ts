﻿export default interface IEmp {
    eno?: any | null ,
    ename: string,
    job: string,
    manager: any | null,
    hiredate: string,
    salary: any | null,
    commission: any | null,
    dno: any | null
}